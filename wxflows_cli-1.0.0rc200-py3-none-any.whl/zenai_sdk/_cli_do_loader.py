# Copyright IBM Corp. 2023, 2024

"""
stepzen.zenai generate stepzen
"""

import asyncio
import io
import json
import logging
import math
import os
import time
import traceback
from abc import ABC, abstractmethod
from typing import (
    IO,
    Any,
    AsyncGenerator,
    Callable,
    Coroutine,
    Dict,
    Generator,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Union,
)

import httpx
import pandas as pd
import yaml
from gql import gql
from graphql import GraphQLSchema
from graphql.error.graphql_error import GraphQLError
from pydantic import BaseModel
from gql.transport.exceptions import TransportQueryError
from tenacity import (
    retry,
    retry_if_exception_type,
    wait_exponential,
    stop_after_attempt,
    after_log,
    RetryCallState,
)

from ._cli_clidata import CLIData
from .cli_error import CLIError
from .zenai_api import AsyncZenUpload, ZenaiUtils

logger = logging.getLogger("wxflows")

model_info = [
    # old sentence transformer models; only good on old generation service
    {
        "name": "all-MiniLM-L6-v2",
        "maxSeqLen": 256,
        "dimensions": 384,
        "size": 80,  # mb
        "model": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2",
    },
    {
        "name": "multi-qa-MiniLM-L6-cos-v1",
        "maxSeqLen": 512,
        "dimensions": 384,
        "size": 80,  # mb
        "model": "https://huggingface.co/sentence-transformers/multi-qa-MiniLM-L6-cos-v1",
    },
    {
        "name": "all-MiniLM-L12-v2",
        "maxSeqLen": 256,
        "dimensions": 384,
        "size": 120,
        "model": "https://huggingface.co/sentence-transformers/all-MiniLM-L12-v2",
    },
    {
        "name": "all-mpnet-base-v2",
        "maxSeqLen": 384,
        "dimensions": 768,
        "size": 420,  # mb
        "model": "https://huggingface.co/sentence-transformers/all-mpnet-base-v2",
    },
    #  move away from this to retrieving the model information from the source (watsonx, etc.)
    # BAM models
    # BAM-r renamed in watsonx, BAM-o bam only, untagged - shared
    {"name": "ibm/slate.125m.english.rtrvr", "maxSeqLen": 512, "dimensions": 768},  # BAM-r
    {"name": "ibm/slate.30m.english.rtrvr", "maxSeqLen": 512, "dimensions": 384},  # BAM-r
    {
        "name": "sentence-transformers/all-minilm-l6-v2",
        "maxSeqLen": 256,
        "dimensions": 384,
    },  # BAM-o
    {"name": "intfloat/multilingual-e5-large", "maxSeqLen": 512, "dimensions": 1024},
    ## watsonx models
    # watsonx renamed the slate models... and added minilm-l12 and don't include L6
    # the id: intfloat/multilingual-e5-large is common between the two.
    {"name": "ibm/slate-125m-english-rtrvr", "maxSeqLen": 512, "dimensions": 768},  # WXAI-r
    {"name": "ibm/slate-30m-english-rtrvr", "maxSeqLen": 512, "dimensions": 384},  # WXAI-r
    {"name": "ibm/slate-125m-english-rtrvr-v2", "maxSeqLen": 512, "dimensions": 768},  # WXAI-r
    {"name": "ibm/slate-30m-english-rtrvr-v2", "maxSeqLen": 512, "dimensions": 384},  # WXAI-r
    {
        "name": "sentence-transformers/all-minilm-l12-v2",
        "maxSeqLen": 256,
        "dimensions": 384,
    },  # WXAI-o
    # {"name": "intfloat/multilingual-e5-large", "maxSeqLen": 512, "dimensions": 1024},
]


chunking = 1000


def load_data(
    fileOrPath: Union[str, IO[bytes], io.TextIOWrapper],
    idColumn: str,
    titleColumn: Optional[str],
    contentColumns: str,
    resultColumn: Optional[str],
) -> Generator[pd.DataFrame, None, None]:
    """
    takes an incoming stream and processes as a TSV file and acts as
    iterator.
    If resultColumn is specified, then combine the title and content columns
    """
    # file or path should accept any of the above types
    tsv = pd.read_csv(
        fileOrPath,  # type: ignore [reportGeneralTypeIssues]
        sep="\t",
        escapechar="\\",
        header=0,
        iterator=True,
        chunksize=chunking,
        dtype="string",
        keep_default_na=False,
    )
    for batch in tsv:
        batch.fillna("")
        if resultColumn:
            if titleColumn:
                # create a "combined" title + content column leaving original
                batch[resultColumn] = batch[titleColumn].astype(str) + "\n" + batch[contentColumns]
            else:
                # copy the content leaving original
                batch[resultColumn] = batch[contentColumns]
        # should check if idColumn exists
        yield batch


class ComputeEmbeddingsService:
    """
    Internal service to compute embeddings
    """

    def __init__(self, model: str):
        """init"""
        host = os.environ.get("ZENAI_EMEDDINGSERVER", "https://embeddings.zenai.stepzen.net")
        self.url = f"{host}/api/v1/{model}/task/embedding-retrieval"
        self.headers = {"Content-Type": "application/json"}

    @staticmethod
    def _processdata(data) -> Any:
        # response is (a) data: [ { data: [ ] }, { data: [ ] }, etc. ]
        # e.g array of responses to calls wrapped as a response
        if "data" not in data:
            return data
        # see if the data has data embedded, if not, then punt
        if len(data["data"]) < 1 or "data" not in data["data"][0]:
            return data
        # response is (a)
        return [x.get("data") for x in data["data"]]

    async def async_encode(self, data) -> Any:
        """
        compute embeddings using zenai internal service
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(self.url, json={"inputs": data}, headers=self.headers)
            response.raise_for_status()
            data = response.json()
        return self._processdata(data)


"""
GraphQL call responses packaged for python.
Consider: if aligning the two sets closer is needed.
"""


class CollectionDropResponse(BaseModel):
    """
    dropCollection response
    """

    ok: bool
    message: Optional[str] = None


class CollectionResponse(BaseModel):
    """
    addCollection response
    """

    ok: bool
    message: Optional[str] = None
    # denseVector: Optional[bool]  # possibly  dense vector
    # documentLimit: Optional[int]  # possibly have a limit


class CloseResponse(BaseModel):
    """
    addDocumentsDone response
    """

    ok: bool
    message: Optional[str] = None


class DocumentsResponse(BaseModel):
    """
    addDocumentRows response.
    """

    count: Optional[int] = None
    rateLimitPauseSecond: Optional[int] = None


class Retryable(Exception):
    """
    used to indicate a retryable exception as determined by GraphQLAPIBased
    """

    def __init__(self, message: str, where: str, exception: Exception):
        self.message = message
        self.where = where
        self.exception = exception


class ZenVectorInterface(ABC):

    @abstractmethod
    def get_collection_name(self) -> str:
        return ""

    @abstractmethod
    async def drop_collection(
        self,
    ) -> CollectionDropResponse:
        pass

    @abstractmethod
    async def add_collection(self, dimensions: int) -> CollectionResponse:
        pass

    @abstractmethod
    async def add_document_rows(self, documents: List[Dict[str, Any]]) -> DocumentsResponse:
        pass

    @abstractmethod
    async def close(self) -> CloseResponse:
        pass

    @abstractmethod
    async def start_transaction(self):
        pass

    @abstractmethod
    async def commit(self):
        pass

    @abstractmethod
    async def rollback(self):
        pass

    @abstractmethod
    async def topNDocs(self):
        """completeness only.  DO NOT IMPLEMENT"""
        pass

    @abstractmethod
    def get_loader_type(self) -> str:
        pass

    @abstractmethod
    def get_zup_call_limit(self) -> int:
        pass

    @abstractmethod
    def get_embedding_model(self) -> str:
        pass

    @abstractmethod
    def get_ai_engine(self) -> str:
        pass

    @abstractmethod
    async def compute_embedding(self, data: List[str], model: str) -> Optional[List[List[float]]]:
        pass

    @abstractmethod
    def get_document_limit(self) -> int:
        pass

    @abstractmethod
    def get_need_embeddings(self) -> bool:
        pass

    @abstractmethod
    def get_collection_args(self) -> Any:
        pass


def after_status() -> Callable[["RetryCallState"], None]:
    def after_status_log(retry_state: "RetryCallState") -> None:
        sec_format: str = "%0.3f"
        logger.log(
            logging.DEBUG,
            f"retry: elapsed time: {sec_format % retry_state.seconds_since_start}(s) "
            f"attempts: {retry_state.attempt_number}.",
        )
        print(
            f"retry: elapsed time: {sec_format % retry_state.seconds_since_start}(s) "
            f"attempts: {retry_state.attempt_number}.",
        )

    return after_status_log


class GraphQLAPIBased(ZenVectorInterface):
    """
    uses GraphQL layer to upload data.
    """

    def __init__(
        self,
        cli: CLIData,
        zup: AsyncZenUpload,
        collection: str,
        loader_type: str,
        loader_subtype: str,
        search_engine: str,
        data: Optional[Dict[str, Any]],
        model: str,
    ):
        self.zup = zup
        # additional data such as index definitions on a per collection basis.
        self.data = data
        if self.data is None:
            self.data = {}
        self.loader_type = loader_type
        self.loader_subtype = loader_subtype
        # see comments about get list of needful fields instead of call prefix
        self.call_prefix = f"ds_{loader_type}_"
        self.collection_name = collection

        debug = cli.is_feature("loader.graphql.debug")
        self.debug = debug
        # discriminate because docs can be huge!
        self.debug_collection = debug or cli.is_feature("loader.graphql.collection.debug")
        self.debug_documents = debug or cli.is_feature("loader.graphql.documents.debug")

        # defaults
        self.document_limit = 1000
        self.need_embeddings = True
        # we'll need a new call to get collection_args
        # since we need to factor in the model/embeddings with it.
        self.collection_args = None

        # force it to be a GraphQL enum
        self.search_engine = search_engine.upper()
        self.embedding_model = model

        # only addDocuments and dropCollection seem like likely candidates
        # so only implement for these two.
        self.retry_allowed = []

        # should get this from the graphql loader LATER
        if self.loader_type == "gettingStarted":
            self.retry_allowed = ["addDocuments"]

    @classmethod
    async def create(
        cls,
        cli: CLIData,
        zup: AsyncZenUpload,
        collection: str,
        loader_type: str,
        loader_subtype: str,
        search_engine: str,
        data: Optional[Dict[str, Any]],
        model: str,
    ):
        self = cls(cli, zup, collection, loader_type, loader_subtype, search_engine, data, model)

        # convoluted because we use the ds_{loader_type}_information call to query the metadata
        # per the gql. Later, clean this up.
        for thetry in range(2):
            try:
                name = f"ds_{loader_type}_information"
                if thetry == 0:
                    query = gql(
                        "query meta($subtype: String, $aiEngine: AIEngine!, $embeddingModel: String!) { "
                        f"information: {name}"
                        "(subtype: $subtype aiEngine: $aiEngine embeddingModel: $embeddingModel"
                        ") { needEmbeddings documentLimit }}"
                    )
                    gql_vars = {
                        "subtype": loader_subtype,
                        "aiEngine": zup.ai_engine_name(),
                        "embeddingModel": model,
                    }
                else:
                    query = gql(
                        "query meta($subtype: String) { "
                        f"information: {name}"
                        "(subtype: $subtype  "
                        ") { needEmbeddings documentLimit }}"
                    )
                    gql_vars = {"subtype": loader_subtype}
                result = await zup.graphql(query, "meta", gql_vars, fetch_schema=True)
                if not result.data:
                    raise RuntimeError(
                        f"{name} did not return expected information and the loader must stop"
                    )
                logger.debug(f"loader setup: {name} used {gql_vars}")
                md = result.data.get("information")
                if md:
                    self.add_metadata(md)
            except GraphQLError as e:
                if str(e).startswith("Unknown argument 'aiEngine' on field ") and thetry == 0:
                    # note: the error still gets shown in debug logs.
                    continue
                if not str(e).startswith("Cannot query field "):
                    raise e
                # okay if information is missing
        try:
            zup.client_schema
        except AttributeError:
            logger.debug("Unable to retreive client schema")
            raise RuntimeError("Unable to process loader type {loader_type}")
        self.adapt_to_schema(zup.client_schema)

        return self

    def add_metadata(self, result: Dict[str, Any]):
        logger.debug(f"add_metadata: {result}")
        if result:
            self.document_limit = result.get("documentLimit", 1000)
            self.need_embeddings = result.get("needEmbeddings", True)
        pass

    def get_document_limit(self) -> int:
        return self.document_limit

    def get_need_embeddings(self) -> bool:
        return self.need_embeddings

    def get_collection_args(self) -> Any:
        return self.collection_args

    def build_operation(
        self, q_name: str, field: Any, marker: Optional[Dict[str, Any]]
    ) -> Tuple[str, Dict[str, Union[str, List[str]]]]:
        def is_aiEngineType(gType: str) -> str:
            if gType == "AIEngine!" or gType == "AIEngine":
                return gType
            return ""

        if not marker or not field:
            return "", {}
        field_arguments = {}
        if field and field.args:
            field_arg_type = {}
            for arg in field.args:
                field_arg_type[arg] = str(field.args[arg].type)
            if marker:
                field_arguments = field_arg_type
                marker["arguments"] = field_arguments
        field_name = marker["field"]
        field_type = marker["type"]

        if q_name == "dropCollection":
            collection_name_type = field_arguments["collectionName"]
            return (
                f"{field_type} dropCollection ($name: {collection_name_type}) "
                " { "
                f"dropCollection: {field_name}(collectionName: $name)"
                " { ok message }  }"
            ), {}
        elif q_name == "addCollection":
            field_has_collection_args = "collectionArgs" in field_arguments
            collection_name_type = field_arguments["collectionName"]
            dimension_type = field_arguments["dimension"]
            collection_query = (
                f"{field_type} {q_name}($name: {collection_name_type}  "
                f"$dimension: {dimension_type})"
                " { "
                f"{q_name}: {field_name}(collectionName: $name  "
                "dimension: $dimension)"
                " { ok message denseVector documentLimit }  }"
            )
            if not field_has_collection_args:
                return collection_query, {}
            logger.debug("add_collection has collection_args")
            return (
                collection_query
                + "\n"
                + (
                    f"{field_type} {q_name}WithCA ($name: {collection_name_type} "
                    f'$collectionArgs: {field_arguments["collectionArgs"]} '
                    f"$dimension: {dimension_type})"
                    " { "
                    f"{q_name}: {field_name}(collectionName: $name  "
                    "collectionArgs: $collectionArgs "
                    "dimension: $dimension)"
                    " { ok message denseVector documentLimit }  }"
                )
                + " \n"
            ), {"variables": ["collectionArgs"]}
        elif q_name == "addDocuments":
            collection_name_type = field_arguments["collectionName"]
            documents_type = field_arguments["documents"]

            # go by type to find aiEngine...
            aiEngine = [name for name in field_arguments if is_aiEngineType(field_arguments[name])]
            extraArguments = ""
            extraInputs = ""
            extraVariables = []
            if aiEngine and len(aiEngine) > 0:
                if len(aiEngine) > 1:
                    raise RuntimeError(f"Unexpected number of AIEngine arguments {aiEngine}")
                aiEngineName = aiEngine[0]
                # fixed name here: $aiEngine as this is what the CLI knows.
                extraArguments = f" $aiEngine: {field_arguments[aiEngineName]}"
                extraInputs = f" {aiEngineName}: ${aiEngineName}"

                logger.debug(
                    f"addDocument needs aiEngine {aiEngineName} {field_arguments[aiEngineName]} "
                )
                extraVariables.append("aiEngine")
            # later: rename extraArguments and Inputs
            if "embeddingModel" in field_arguments:
                extraArguments += f" $embeddingModel: {field_arguments['embeddingModel']}"
                extraInputs += " embeddingModel: $embeddingModel"
                logger.debug(
                    f"addDocument needs embeddingModel {field_arguments['embeddingModel']}"
                )
                extraVariables.append("embeddingModel")
            return (
                f"{field_type} addDocuments ($name: {collection_name_type} $documents: {documents_type} {extraArguments}) "
                "{ "
                f"addDocuments: {field_name}(collectionName: $name documents: $documents {extraInputs}) "
                " { rateLimitPauseSecond }}"
            ), {"variables": extraVariables}
        elif q_name == "addDocumentsDone":
            collection_name_type = field_arguments["collectionName"]
            return (
                f"{field_type} addDocumentsDone($name: {collection_name_type}) {{"
                f"addDocumentsDone: {field_name}"
                "(collectionName: $name) { ok } }"
            ), {}
        return "", {}

    def adapt_to_schema(self, schema: Optional[GraphQLSchema]):
        if not schema:
            raise RuntimeError("Unable to determine loaders")
        self.schema = schema
        subtype = self.loader_subtype
        thetype = self.loader_type

        # build table of queries
        # some should be mutations, but due to sequence limits may have been implemented as queries.
        queries = [
            "search",
            "information",
            "topNDocs",
            "addCollection",
            "addDocuments",
            "addDocumentsDone",
            "dropCollection",
        ]
        markers = {}
        name = f"ds_{thetype}"
        name2 = f"ds_{thetype}_{subtype}"

        query_fields = schema.query_type.fields if schema.query_type else {}
        mutation_fields = schema.mutation_type.fields if schema.mutation_type else {}
        # this code can be simplified
        operations = {}
        flags = {}
        for q in queries:
            result: Optional[Mapping[str, Any]] = None
            field = None
            if f"{name2}_{q}" in mutation_fields:
                result = {"type": "mutation", "field": f"{name2}_{q}"}
                field = mutation_fields[f"{name2}_{q}"]
            elif f"{name}_{q}" in mutation_fields:
                result = {"type": "mutation", "field": f"{name}_{q}"}
                field = mutation_fields[f"{name}_{q}"]
            elif f"{name2}_{q}" in query_fields:
                result = {"type": "query", "field": f"{name2}_{q}"}
                field = query_fields[f"{name2}_{q}"]
            elif f"{name}_{q}" in query_fields:
                result = {"type": "query", "field": f"{name}_{q}"}
                field = query_fields[f"{name}_{q}"]
            op, op_flags = self.build_operation(q, field, result)
            if op:
                operations[q] = op
            if op_flags:
                flags[q] = op_flags

            if not result:
                logger.debug(f"{q} has no implementation for ds_{thetype}_{subtype}")
            else:
                markers[q] = result
        self.markers = markers
        self.flags = flags
        self.operations = operations
        self.gql_document = gql("\n".join([operations[opname] for opname in operations]))
        logger.debug("operations:")
        for opname in operations:
            logger.debug(f" - {opname}: {operations[opname]}")
        if len(operations) == 0:
            raise RuntimeError(
                "Unable process an upload using {self.loader_type} as the schema is missing any needed fields"
            )

    def get_collection_name(self) -> str:
        return self.collection_name

    @retry(
        stop=stop_after_attempt(2),
        after=after_log(logger, logging.DEBUG),
        retry=(retry_if_exception_type(Retryable)),
        wait=wait_exponential(multiplier=1, min=4, max=15),
        reraise=True,
    )
    async def drop_collection(
        self,
    ) -> CollectionDropResponse:
        """
        drop the namedcollection
        would also be useful to have a getCollectionInfo but defer this for some time
        (or at least make it not required)
        """
        marker = self.markers.get("dropCollection")
        if not marker:
            return CollectionDropResponse(ok=True, message="")
        retryable = "dropCollection" in self.retry_allowed
        field_name = marker["field"]
        variables = {"name": self.collection_name}
        logger.debug(f"drop_collection with marker {marker}")
        try:
            res = await self.zup.graphql(
                self.gql_document,
                "dropCollection",
                variables,
                debug=self.debug_collection,
            )
        except TransportQueryError as e:
            if not retryable or not e.errors or len(e.errors) < 1:
                raise
            # this is not particularly helpful for dropcollection
            msg = e.errors[0].get("message")
            if msg == "timeout: field resolution exceeded available time":
                logger.debug(
                    f"{msg}: dropCollection: retry on timeout: field resolution exceeded available time"
                )
                raise Retryable(msg, "dropCollection", e)
            raise

        if self.debug_collection:
            logger.debug(
                f"{field_name}: dropCollection {json.dumps(variables)} {json.dumps(res.extensions, indent=2)}"
            )
        if not res.data:
            raise RuntimeError(f"{field_name} did not return data")

        result = res.data.get("dropCollection", {})
        ok = result.get("ok")
        if ok is None:
            e = RuntimeError(
                f"Failure while dropping collection: return value was empty indicating {field_name} did not return a value due to failure or an implementation issue."
            )
            # disable this pathway until we understand this better
            if retryable and False:
                e = Retryable(str(e), "dropCollection", e)
            raise e

        return CollectionDropResponse(ok=ok, message=result.get("message", ""))

    async def add_collection(self, dimensions: int) -> CollectionResponse:
        """
        add collection with optional collectionArgs from data
        """
        marker = self.markers.get("addCollection")
        if not marker:  # treat it as a no-op
            return CollectionResponse(ok=True, message="")

        field_name = marker["field"]
        flags = self.flags.get("addCollection")
        logger.debug(f"add_collection with marker {marker}")

        variables = {"name": self.collection_name, "dimension": dimensions}
        op_name = "addCollection"
        if (
            self.get_collection_args()
            and flags
            and flags.get("variables")
            and "collectionArgs" in flags.get("variables")
        ):
            cargs = self.get_collection_args()
            variables["collectionArgs"] = cargs
            op_name = "addCollectionWithCA"
            logger.debug(f"Sending collectionArgs {variables} {op_name}")

        res = await self.zup.graphql(
            self.gql_document, op_name, variables, debug=self.debug_collection
        )
        if self.debug_collection:
            logger.debug(
                f"{field_name}: {op_name} {json.dumps(variables)} {json.dumps(res.extensions, indent=2)}"
            )
        if not res.data:
            raise RuntimeError(f"{field_name} did not return data")

        result = res.data.get("addCollection", {})
        if not result:
            raise Exception(f"Unexpected failure of {op_name}")
        ok = result.get("ok")
        if ok is None:
            raise RuntimeError(
                f"Failure while adding collection: return value was empty indicating {field_name} did not return a value due to failure or an implementation issue."
            )
        return CollectionResponse(
            ok=result.get("ok", False),
            message=result.get("message", ""),
        )

    @retry(
        stop=stop_after_attempt(3),
        after=after_status(),
        retry=(retry_if_exception_type(Retryable)),
        wait=wait_exponential(multiplier=1, min=4, max=15),
        reraise=True,
    )
    async def add_document_rows(self, documents: List[Dict[str, Any]]) -> DocumentsResponse:
        """
        add rows to collection
        """
        marker = self.markers.get("addDocuments")
        if not marker:
            raise RuntimeError(
                f"Could not add rows.  Missing loader method for {self.loader_type}_{self.loader_subtype}"
            )

        retryable = "addDocuments" in self.retry_allowed
        field_name = marker["field"]
        flags = self.flags.get("addDocuments")
        variables = {"name": self.collection_name, "documents": documents}
        if flags and flags.get("variables"):
            if "aiEngine" in flags.get("variables"):
                aiEngine = self.get_ai_engine()
                variables["aiEngine"] = aiEngine  # matches $aiEngine in operation
            if "embeddingModel" in flags.get("variables"):
                variables["embeddingModel"] = self.get_embedding_model()

        logger.debug(
            f'add_document_rows with {self.collection_name}  docs {len(variables.get("documents", []))} aiEngine {variables.get("aiEngine")}'
        )
        try:
            res = await self.zup.graphql(
                self.gql_document,
                "addDocuments",
                variables,
                debug=self.debug_documents,
            )
        except TransportQueryError as e:
            if not retryable or not e.errors or len(e.errors) < 1:
                raise
            # eventually we'll need to dig deeper into messages as some of the watsonx messages
            # will show up here.
            # addDocumentRowsDone retries later perhaps, but it will need to be type by type
            # since  calling addDocumentRowsDone multiple times is not necessarily always safe.
            for i in range(len(e.errors)):
                # TODO: add tests for these error cases - done by adding synthetic addDocuments
                # graphql that returns the expected errors.
                msg = e.errors[i].get("message")
                # this is a specific error message that is returned by the zenserv graphql layer
                if msg == "timeout: field resolution exceeded available time":
                    # print("addDocuments: retry...", str(Retryable(msg, "addDocuments", e)))
                    logger.debug(f"{msg}: addDocuments: retry {e}")
                    # so can get here if the operation takes too long, this has happened in the past
                    # and have yet to deterimine if it was embeddings or addDocuments that timed out.
                    # but in either case, for some (gettingStarted, milvus upsert)it is a idempotent
                    # operation, so we can retry
                    raise Retryable(msg, "addDocuments", e)
                # digging deeper
                # for when the watsonx error come back as a string:
                # watsonx specific retryable errors that we wish to catch and retry #1339,  #1359
                # many errors are not worth retrying but enumerating will miss, but this will err on the
                # side of specific for now.  [Would prefer to exclude all 400 class errors]
                if self.get_ai_engine() == "WATSONX" and (
                    (
                        "Downstream FMAAS request with '" in msg
                        and "failed: Already borrowed" in msg
                    )
                    or ("Rate limit of " in msg and "was reached for instance id" in msg)
                ):
                    logger.debug(f"{msg}: addDocuments: retry {e}")
                    raise Retryable(msg, "addDocuments", e)
                # note: connector errors are what are sent back from @rest directly when the status code is set
                # for some APIs, retrying some of this is not appropriate but we only retry a small
                # number of times and with a lag, so the main negative effect is a delay before
                # reporting the error...
                if (
                    (msg == "Connector: HTTP Error: Too Many Requests")
                    or (msg == "Connector: HTTP Error: Internal Server Error")
                    or (msg == "Connector: HTTP Error: Bad Gateway")
                    or (msg == "Connector: HTTP Error: Service Unavailable")
                    or (msg == "Connector: HTTP Error: Gateway Timeout")
                ):
                    logger.debug(f"{msg}: addDocuments: retry {e}")
                    raise Retryable(msg, "addDocuments", e)

            raise
        if self.debug_documents:
            logger.debug(
                f"{field_name}: {self.operations.get('addDocuments')} {json.dumps(variables)} {json.dumps(res.extensions, indent=2)}"
            )
        if not res.data:
            raise RuntimeError(f"{field_name} did not return data")
        rate_limit_pause = 0
        add_document = res.data.get("addDocuments", {})
        if add_document is None:
            # usually get here when sequence prematurely ends.
            e = RuntimeError(
                f"Failure while adding document rows: return value was empty indicating {field_name} did not return a value due to failure or an implementation issue."
            )
            if retryable:
                logger.debug(f"retry due to addDocuments {e}")
                e = Retryable(str(e), "addDocuments", e)
            raise e
        # values will be None
        rate_limit_pause = (
            0
            if add_document.get("rateLimitPauseSecond") is None
            else add_document.get("rateLimitPauseSecond")
        )
        if rate_limit_pause:
            logger.debug(f"{field_name}: rate_limit_pause = {rate_limit_pause}")
        count = 0 if add_document.get("count") is None else add_document.get("count")
        return DocumentsResponse(rateLimitPauseSecond=math.floor(rate_limit_pause), count=count)

    async def close(self) -> CloseResponse:
        """
        final step which will call `addDocumentsDone` to allow
        triggering of any final actions needed.

        currently no additional data to be passed
        """

        marker = self.markers.get("addDocumentsDone")
        if not marker:
            return CloseResponse(ok=True, message="")
        field_name = marker.get("field")

        logger.debug(f"add_document_rows_done/close {field_name}")
        res = await self.zup.graphql(
            self.gql_document,
            "addDocumentsDone",
            {"name": self.collection_name},
            debug=self.debug_documents,
        )
        if not res.data:
            raise RuntimeError(f"{field_name} did not return data")
        add_document = res.data.get("addDocumentsDone", {})
        if add_document is None:
            raise RuntimeError(
                f"Failure ending addDocumentsDone: return value was empty indicating {field_name} did not return a value due to failure or an implementation issue."
            )
        return CloseResponse(ok=add_document.get("ok", False), message="")

    async def start_transaction(self):
        pass

    async def commit(self):
        pass

    async def rollback(self):
        pass

    async def topNDocs(self):
        """completeness only.  DO NOT IMPLEMENT"""
        pass

    def get_loader_type(self) -> str:
        return self.loader_type
        pass

    def get_zup_call_limit(self) -> int:
        return self.zup.call_limit

    def get_embedding_model(self) -> str:
        return self.embedding_model

    def get_ai_engine(self) -> str:
        return self.zup.ai_engine_name()

    # Coroutine[Any, Any,
    async def compute_embedding(self, data: List[str], model: str) -> Optional[List[List[float]]]:
        return await self.zup.compute_embedding(data, model)


def package_chunk_to_doc(
    chunk: Any, enc: Optional[List[List[float]]] = None
) -> List[Dict[str, Any]]:
    docs = chunk
    for i, doc in enumerate(docs):
        if enc:
            doc["embedding"] = enc[i]
        if "text" in doc:
            del doc["text"]
        if "title" in doc:
            del doc["title"]
    return docs


async def chunks_to_embedded_docs(
    compute_embedding: Callable[[List[str]], Coroutine[Any, Any, Optional[List[List[float]]]]],
    chunk: List[Dict[str, str]],
    call_limit: int,
) -> Tuple[List[Dict[str, Any]], int]:
    """convert chunks to docs with encoding"""
    ncontent = len(chunk)
    if ncontent > 0:
        if "embedding" in chunk[0]:
            # tsv is 'str' so we'll have to convert...
            for i in range(len(chunk)):
                if isinstance(chunk[i]["embedding"], str):
                    try:
                        chunk[i]["embedding"] = json.loads(chunk[i]["embedding"])
                    except Exception as e:
                        logger.debug(
                            f'Error {e} occurred while decoding the embedding, index {i} {len(chunk[i]["embedding"])}'
                        )
                        raise e
            logger.info(
                f'embedding found in first document of this chunk, skipping embedding {len(chunk[0]["embedding"])}'
            )
            return chunk, 0

    enc = []
    start_time = time.time()
    embeds = math.ceil(ncontent / call_limit)
    for i in range(embeds):
        lim = min((i + 1) * call_limit, ncontent)
        partial: List[str] = [chunk[j].get("content", "") for j in range(i * call_limit, lim)]
        penc = await compute_embedding(partial)
        if penc is None:
            raise RuntimeError("Unexpected failure while computing embeddings")
        enc.extend(penc)
    docs = package_chunk_to_doc(chunk, enc)
    logger.info(
        f"embedding {ncontent}/{embeds}x{call_limit if call_limit<ncontent else ncontent} took {time.time() - start_time}"
    )
    return docs, embeds


async def process(
    out: Callable[[str], None],
    vdb: ZenVectorInterface,
    zapi: Any,
    getdata: Callable[[Optional[int]], AsyncGenerator[pd.DataFrame, None]],
    account: str,
    model: str,
    replace: bool,
    dump: bool,
) -> int:
    """process url with token"""
    count = 0
    start = time.time()
    progress = 0

    mychunking = chunking
    # note: we really want only
    # engines that don't do rate limit pause
    doasync = vdb.get_ai_engine() == "WATSONX"
    # only if allowed for now.
    if "WXFLOWS_LOADER_INSERT_PARALLELISM" not in os.environ:
        doasync = False

    logger.debug(
        f"Processing collection {vdb.get_collection_name()} for account {account} model: {model} "
        f"document store: {vdb.get_loader_type()} "
        f"replace: {replace}"
    )

    lmodel_information = [mi for mi in model_info if mi["name"] == model]
    if len(lmodel_information) != 1:
        raise RuntimeError(f"Unknown or bad model: {model} for AI Engine {vdb.get_ai_engine()}")
    model_information = lmodel_information[0]

    need_embedding = True
    if dump:
        logger.info("dumping to expert/dumps")
        os.makedirs(os.path.join("expert", "dumps"), exist_ok=True)

    # subchunk is used to split up the chunk into reasonable
    # limits for encoding and database presentation
    subchunk = 100

    # insert_limit is for the database presentation
    insert_limit = subchunk
    # encoding batch size
    call_limit = subchunk

    if vdb.get_zup_call_limit():
        call_limit = vdb.get_zup_call_limit()

    if vdb.get_document_limit():
        insert_limit = vdb.get_document_limit()

    if vdb.get_ai_engine() == "WATSONX":
        if insert_limit == 18 and vdb.get_loader_type() == "gettingStarted":  # old case
            insert_limit = 200
            logger.debug(
                f"loader: override gettingStarted insert limit of 18 for watsonx: {insert_limit}"
            )
        if "WATSONX_INSERT_LIMIT" in os.environ:
            insert_limit = int(os.environ["WATSONX_INSERT_LIMIT"])
            logger.debug(f"loader: override insert limit for watsonx: {insert_limit}")

    if doasync:
        if "WXFLOWS_LOADER_INSERT_PARALLELISM" in os.environ:
            inserts = int(os.environ["WXFLOWS_LOADER_INSERT_PARALLELISM"])
        else:
            inserts = 5
        if inserts > 20:
            logger.debug(f"inserts parallelism {inserts} above 20 not recommended, limiting")
            inserts = 20
        mychunking = insert_limit * inserts
        logger.debug(f"loader async {doasync} chunking {mychunking}")

    need_embedding = vdb.get_need_embeddings()
    if replace:
        try:
            await vdb.drop_collection()
        except Exception as e:
            logger.debug(f"Drop collection {e}")
            out("Problems dropping collection... proceeding...")
        result = await vdb.add_collection(model_information["dimensions"])
        if not result.ok:
            raise RuntimeError(f"Error occurred adding connection: {result.message}")
        await vdb.start_transaction()
    rate_limit_pause = 0

    if need_embedding:
        logger.debug(f"encoding call limit {call_limit}")
        if call_limit > mychunking:
            logger.debug(
                f"encoding call limit {call_limit} bottlenecked by chunksize of {mychunking}"
            )
    else:
        logger.debug("No embeddings will be computed - not required")
    logger.debug(f"database insert limit: {insert_limit}")
    if insert_limit > mychunking:
        logger.debug(
            f"database insert limit: {insert_limit} bottlenecked by chunksize of {mychunking}"
        )

    async def compute_embedding(partial: List[str]):
        return await vdb.compute_embedding(partial, model)

    # logging stats, kept simple
    EMBEDDING_TIME = "Embeddings time"
    EMBEDDING_COUNT = "Embeddings calls"
    UPLOADS_TIME = "Upload API time"
    UPLOADS_COUNT = "Upload API calls"
    DATA_ROWS = "Data rows"
    stats = {
        EMBEDDING_TIME: 0.0,
        EMBEDDING_COUNT: 0,
        UPLOADS_TIME: 0.0,
        UPLOADS_COUNT: 0,
        DATA_ROWS: 0,
    }

    # note: the code to load *other* columns is missing
    # we need to adjust load_data to pull in all columns...
    idx = 0
    async for pchunk in getdata(mychunking):
        chunk = pchunk.to_dict(orient="records")
        # now do the encodings
        if need_embedding:
            st = time.time()
            docs, cnt = await chunks_to_embedded_docs(compute_embedding, chunk, call_limit)
            if cnt:
                stats[EMBEDDING_TIME] += time.time() - st
                stats[EMBEDDING_COUNT] += cnt
        else:
            docs = package_chunk_to_doc(chunk)

        ncontent = len(docs)
        count += ncontent
        stats[DATA_ROWS] += ncontent
        st = time.time()
        if dump:
            with open(os.path.join("expert", "dumps", str(idx) + ".json"), "w") as f:
                f.write(json.dumps(docs))
        start_time = time.time()
        inserts = math.ceil(ncontent / insert_limit)

        tasks = []
        for i in range(inserts):
            if len(docs) < i * insert_limit:
                break
            # assert(len(docs[i * insert_limit : (i + 1) * insert_limit]),insert_limit)
            if rate_limit_pause:
                out(f"pause {rate_limit_pause}")
                time.sleep(rate_limit_pause)
            partial = docs[i * insert_limit : (i + 1) * insert_limit]
            if doasync:
                task = asyncio.create_task(vdb.add_document_rows(partial))
                tasks.append(task)
                logger.debug(f"task {task} created")
            else:
                res = await vdb.add_document_rows(partial)
                rate_limit_pause = res.rateLimitPauseSecond
            stats[UPLOADS_COUNT] += 1

        if doasync:
            exceptions = []
            for task in tasks:
                await task
                logger.debug(f"collected {task}")
                if task.exception():
                    logger.debug(f"task {task} exception: {task.exception()}")
                    exceptions.append(str(task.exception()))
                elif task.result() and task.result().rateLimitPauseSecond:
                    logger.debug(f"task {task} result: {task.result()}")
            if exceptions:
                logger.debug(f"Task exceptions {exceptions}")
                raise RuntimeError("Exception" + ",".join(exceptions))
        stats[UPLOADS_TIME] += time.time() - start_time

        if count > progress:
            delta = time.time() - start
            out(
                f"Processing {account}/{vdb.get_collection_name()} {count} fragments "
                f" {round(delta,2)}s elapsed"
            )
            progress += max(1000, mychunking)
        logger.info(
            f"inserts {len(docs)}/{inserts}x{insert_limit if insert_limit < ncontent else ncontent} took {time.time() - start_time}"
        )
        idx += 1
    logger.info(f"stats: {json.dumps(stats, indent=4)}")
    out(
        f"Processed {account}/{vdb.get_collection_name()} count {count} "
        f"fragments {round(time.time() - start,2)} elapsed"
    )

    await vdb.commit()
    await vdb.close()

    return count


def build_reader(
    chunk_size: int,
    tsvFileOrPaths: Sequence[Union[str, IO[bytes], io.TextIOWrapper]],
    idColumn: str,
    titleColumn: Optional[str],
    contentColumns: str,
    resultColumn: Optional[str],
    convert: bool = True,
    remove: bool = True,
    reload: bool = False,
) -> Callable[[Optional[int]], AsyncGenerator[pd.DataFrame, None]]:
    """creates a generator function to return data in chunks
    input is based upon:
    tsvFileOrPaths - a list of files (or URIs) where each files treated
    as a TSV [ possibly allow csv, other formats ]

    Within each file:
    if a contentColumns [text] exists, it will be moved to the resultColumn [content]
    if a titleColumn exists it will be prepended
    if no contentColumns [text] exists, the incoming TSV is passed through.

    the idColumn is not checked and will be passed through.

    All columns are strings.
    """

    def compute_seperator_from_name(
        fileOrPath: Union[str, IO[bytes], io.TextIOWrapper]
    ) -> Optional[str]:
        # default for for incoming streams is None?
        if not isinstance(fileOrPath, str):
            return None

        if "://" in fileOrPath and (fileOrPath[0] != "."):  # is it a URI?
            # problem with this heuristic is that files
            # names with '<value>://' locally wont't be addressible
            from urllib.parse import urlparse

            parsed_url = urlparse(fileOrPath)
            ext = os.path.splitext(parsed_url.path)[1].lower()
        else:
            ext = os.path.splitext(fileOrPath)[1].lower()
        if ext == ".tsv":
            return "\t"
        elif ext == ".json":
            return None
        elif ext == ".jsonl":
            return None
        elif ext == ".csv":
            return ","
        logger.debug("Using default separator")
        return "\t"  # make this the default for now

    async def _reader(batch_size: Optional[int] = None) -> AsyncGenerator[pd.DataFrame, None]:
        """
        takes an incoming stream and processes as a TSV file and acts as
        iterator.
        If resultColumn is specified, then combine the title and content columns
        """
        idx = 0
        if not batch_size:
            batch_size = chunk_size
        for fileOrPath in tsvFileOrPaths:
            sep = compute_seperator_from_name(fileOrPath)
            if sep:
                pdReader = pd.read_csv(
                    fileOrPath,  # type: ignore [reportGeneralTypeIssues]
                    sep=sep,
                    header=0,
                    iterator=True,
                    chunksize=batch_size,
                    dtype="string",
                )
            else:
                # nothing here to handle this case.
                logger.debug("no seperator for {fileOrPath}, not handled for now")
                continue
            logger.debug(f"using separator={json.dumps(sep)} for {fileOrPath}")

            for batch in pdReader:
                if reload:
                    # during the reload path, we replace the chunk with previously
                    # existing data
                    it = os.path.join("expert", "dumps", str(idx) + ".json")
                    if os.path.exists(it):
                        with open(it, "r") as f:
                            data = f.read()
                            logger.info(f"reload on {it} length {len(data)}")
                            yield json.loads(data)
                            idx += 1
                            continue

                if convert and resultColumn and contentColumns in batch.columns:
                    # Keep NA (empty values) and don't do the title
                    # replacement if all titles are empty
                    if (
                        titleColumn
                        and titleColumn in batch.columns
                        and len(batch[titleColumn].value_counts()) > 0
                    ):
                        batch.fillna("", inplace=True)
                        # create a "combined" title + content column
                        # and *remove* the original
                        batch[resultColumn] = batch[titleColumn] + "\n" + batch[contentColumns]
                        if remove:
                            del batch[titleColumn]
                            del batch[contentColumns]
                    else:
                        batch.fillna("", inplace=True)
                        # copy the content leaving original
                        batch[resultColumn] = batch[contentColumns]
                        if remove:
                            del batch[contentColumns]
                            if titleColumn in batch.columns:  # most likely empty
                                del batch[titleColumn]
                else:
                    batch.fillna("", inplace=True)
                # should check if idColumn exists
                yield batch

    return _reader


def build_reader_basic(
    tsvFileOrPaths: Sequence[Union[str, IO[bytes], io.TextIOWrapper]],
    chunking: int = 500,
    convert: bool = True,
    remove: bool = True,
) -> Callable[[Optional[int]], AsyncGenerator[pd.DataFrame, None]]:
    return build_reader(
        chunking,
        tsvFileOrPaths,
        "id",
        "title",
        "text",
        "content",
        convert=convert,
        remove=remove,
        reload=False,
    )
    pass


def process_objects(
    out: Callable[[str], None],
    vdb: ZenVectorInterface,
    zapi: Any,
    chunked_data_files: List[str],
    account: str,
    model: str,
    replace: bool = False,
    dump: bool = False,
    reload: bool = False,
):
    """
    currently just sends in the open file, but eventually could send in *any* stream
    source including cloud objects functions, etc.
    """

    global chunking

    if "WXFLOWS_LOADER_CHUNKING" in os.environ:
        chunking = int(os.environ["WXFLOWS_LOADER_CHUNKING"])
        logger.debug(f"loader: override chunking for watsonx: {chunking}")

    # allows us to have process_objects callable via SDK
    # lots more work before that's viable, but this is a core element.
    if not out:
        # if nothing passed, then we're probably not
        # in place we want to print output, so log it.
        def logmsg(msg: str):
            """wrap this"""
            logger.debug(msg)

        out = logmsg
    count = asyncio.run(
        process(
            out,
            vdb,
            zapi,
            build_reader(
                chunking, chunked_data_files, "id", "title", "text", "content", reload=reload
            ),
            account,
            model,
            replace,
            dump,
        )
    )
    return count


def load_data_file(filename: str) -> Dict[str, Any]:
    """
    contains extra data for the loader.
    primary key is the graphql function name (e.g. vdb_zillis_addCollection)
    secondary key are known arguments such as collectionArgs [ will extend this later ]
    """
    if not filename:
        return {}
    with open(filename, "rb") as f:
        if os.path.splitext(filename)[1].lower() == "json":
            return json.load(f)
        return yaml.safe_load(f)


def upload_and_process_local(  # pylint: disable=R0913
    console: Any,
    cli: CLIData,
    zapi: Any,
    zup: AsyncZenUpload,
    account: str,
    chunked_data_files: List[str],
    collection: str,
    model: str,
    loader_data_file: str,
    loader_type: str,
    loader_subtype: str,
    search_engine: str,
    run_vectors: bool = True,
    check_files: bool = False,
    collection_mode: str = "none",
):
    """
    upload and process a file with minimum progress bar
    """

    def out(msg: str):
        """wrap this"""
        console.print(msg)

    try:
        logger.debug(
            f"loader: account {account} filename {' '.join(chunked_data_files)} collection {collection} "
            f"model {model} prefix {loader_type} subtype {loader_subtype} runvectors {run_vectors}"
        )
        zenutils = ZenaiUtils()
        if check_files:
            [zenutils.check_object(filename) for filename in chunked_data_files]
        if model == "mini":
            model = "sentence-transformers/all-minilm-l6-v2"

        loader_data = {}  # disable
        vdb = asyncio.run(
            GraphQLAPIBased.create(
                cli,
                zup,
                collection,
                loader_type,
                loader_subtype,
                search_engine,
                loader_data,
                model,
            )
        )

        if collection_mode == "drop":
            with console.status(f"Removing {collection}..."):
                try:
                    result = asyncio.run(vdb.drop_collection())
                    if not result.ok and result.message:
                        out(result.message)
                except Exception as e:
                    logger.debug(f"Drop collection {e}")
                    out("Problems dropping collection... proceeding...")

            return

        dump = cli.is_feature("loader.dump")
        reload = cli.is_feature("loader.reload")

        with console.status("Uploading..."):
            process_objects(
                out,
                vdb,
                zapi,
                chunked_data_files,
                account,
                model,
                collection_mode == "replace",
                dump,
                reload,
            )
    except RuntimeError as e:
        raise CLIError("An error occurred while uploading data: " + str(e))
    except Retryable as e:
        raise CLIError("An error occurred while uploading data: " + str(e.exception))
    except CLIError as e:
        logger.debug(f"{traceback.format_exc()}")
        raise e
    except Exception as e:
        logger.debug(f"{traceback.format_exc()}")
        raise CLIError("An error occurred while uploading data: " + str(e))
