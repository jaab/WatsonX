# Copyright IBM Corp. 2023, 2024
import json
import logging
import os
from typing import Any, Dict, List, Mapping, Optional, Tuple, Union

import tomlkit

from .cli_error import CLIError

logger = logging.getLogger("wxflows")

_NAME = "wxflows"
_WATZENTOML = f"{_NAME}.toml"
_DEFAULT_PATTERN = "aicore"
_DEFAULT_GENAI = "WATSONX"
_DEFAULT_NAME = f"{_NAME}-genai"
_DEFAULT_ENDPOINT = f"{_NAME}-genai/endpoint"
_DEFAULT_DOCSTORE = "gettingStarted"
_DEFAULT_COLLECTION = "wxflows-default"
_FLOW_EXT = ".flow"

_PYPROJECT_NAME = _NAME


class DocStore:
    def __init__(self, docstore: Dict[str, Any] = {}):
        self.data = docstore
        pass

    def raw_data(self) -> Dict[str, Any]:
        return self.data

    def type(self) -> str:
        if not self.data:
            return ""
        v = self.data.get("type")
        return v if v else ""

    def subtype(self) -> str:
        if not self.data or not self.data.get("type"):
            return ""
        return self.data.get(self.type(), {}).get("subtype", "")

    def data_file(self) -> str:
        if not self.data or not self.data.get("type"):
            return ""
        return self.data.get(self.type(), {}).get("data_file")


class Endpoints:

    @staticmethod
    def guard(name: str, data: Any) -> Mapping[str, Mapping[str, Any]]:
        if not data:
            return {}
        if not isinstance(data, Mapping):
            raise CLIError(f"expected a mapping for {name}")
        for x in data:
            if not isinstance(data[x], Mapping):
                raise CLIError(f"expected a mapping for {name}.{x}")
        return data

    @staticmethod
    def guard_imports(
        name: str, data: Any
    ) -> Union[Mapping[str, Mapping[str, Any]], List[Mapping[str, Any]]]:
        if not data:
            return {}
        if not isinstance(data, Mapping) and not isinstance(data, List):
            raise CLIError(f"expected a list or mapping for {name}")
        if isinstance(data, List):
            for idx, item in enumerate(data):
                if not isinstance(item, Mapping):
                    raise CLIError(f"expected a mapping for {name}[{idx}]")
        else:
            for x in data:
                if not isinstance(data[x], Mapping):
                    raise CLIError(f"expected a mapping for {name}.{x}")
        return data

    def __init__(self, data: Mapping[str, Any]):
        if data is None:
            data = {}
        # Convert from TOML to JSON
        # because YAML doesn't repr TOML
        data = json.loads(json.dumps(data))
        self.raw_data = data
        self.tools = data.get("tools", [])
        imports = data.get("imports")
        self.imports: Union[Mapping[str, Mapping[str, Any]], List[Mapping[str, Any]]] = (
            self.guard_imports("imports", imports)
        )
        extensions = data.get("extensions")
        self.extensions: Union[Mapping[str, Mapping[str, Any]], List[Mapping[str, Any]]] = (
            self.guard_imports("extensions", extensions)
        )

        # really a Mapping[str, Mapping[str, str]] but may need todo type conversion of bool, etc.
        self.configuration: Mapping[str, Mapping[str, Any]] = self.guard(
            "configuration", data.get("configuration")
        )
        self.deployment: Mapping[str, Mapping[str, Any]] = self.guard(
            "deployment", data.get("deployment")
        )

        self.access = data.get("access")

    def tools_list(self) -> List[Mapping[str, Any]]:
        return self.tools

    def imports_and_extensions(self) -> List[Mapping[str, Any]]:
        def fix(k, v) -> Mapping[str, Any]:
            if "name" not in v:
                v["name"] = k
            return v

        def map_to_list(it) -> List[Mapping[str, Any]]:
            return [fix(k, v) for k, v in it.items() if v]

        if isinstance(self.imports, list):
            left = self.imports
        else:
            left = map_to_list(self.imports)
        if isinstance(self.extensions, list):
            right = self.extensions
        else:
            right = map_to_list(self.extensions)
        return left + right


def _get_toml(location: str) -> Tuple[str, str, List[str], tomlkit.TOMLDocument]:
    """get toml loads toml from specified location (directory or file )"""
    tf = None
    logger.debug(f"toml location {location}")
    if os.path.isfile(location):
        logger.debug(f"loading toml from {location}")
        tf = location
    else:
        if os.path.isfile(os.path.join(location, _WATZENTOML)):
            tf = os.path.join(location, _WATZENTOML)
            logger.debug("loading toml from {tf} using defaults")
    if not tf:
        logger.debug("No TOML")
        # ugly
        if location == _WATZENTOML:
            sloc = ""
        else:
            sloc = location
        anno = ""
        # fallback to pyproject.toml so there can be a single integrated project file.
        if os.path.exists(os.path.join(sloc, "pyproject.toml")):
            with open(os.path.join(sloc, "pyproject.toml"), "rb") as f:
                tomldata = tomlkit.parse(f.read())
                tool = tomldata.get("tool", {})
                if _PYPROJECT_NAME in tool:
                    logger.debug(f"Using pyproject.toml as it has tool.{_PYPROJECT_NAME} entries")
                    return (
                        os.path.dirname(location),
                        "pyproject.toml",
                        ["tool", f"{_PYPROJECT_NAME}"],
                        tool,
                    )
                else:
                    anno += f" and pyproject.toml is missing tool.{_PYPROJECT_NAME} entry"
        if sloc:
            raise CLIError(f"{_WATZENTOML} file not found in '{sloc}'{anno}")
        else:
            raise CLIError(f"{_WATZENTOML} file not found{anno}")

    logger.debug(f"loading toml from {tf}")
    with open(tf, "rb") as f:
        tomldata = tomlkit.parse(f.read())
    output_directory = os.path.dirname(tf)
    # checks to see if this was actually a pyprojct.toml
    if "tool" in tomldata and "wxflows" not in tomldata:
        tool = tomldata.get("tool", {})
        return output_directory, tf, [], tool
    return output_directory, tf, [], tomldata


class Configuration:
    """
    controlled location for wxflows configuration
    current:
    - held in wxflows.toml
    - note: at present, this data is grabbed directly, redirect everything here over time.
    """

    BAM = "BAM"
    WATSONX_AI = "WATSONX"

    # def __init__(self, tdata: Dict[str, Any]):   # hack
    def __init__(self, tdata: tomlkit.TOMLDocument):
        self.configuration_data = tdata
        # cache these.
        self.stepzen_cli_data = tdata.get("stepzen", {}).get("cli", {})
        # allow for [flows.deployment], or [watzen.deployment] or [wxflows.deployment]
        if _NAME in tdata:
            self.watzen_deployment_data = tdata.get(_NAME, {}).get("deployment", {})
            logger.debug(f"configuration: {_NAME}")
        elif "flows" in tdata:
            # deprecated
            self.watzen_deployment_data = tdata.get("flows", {}).get("deployment", {})
            logger.debug("configuration: flows")
        else:
            # deprecated
            self.watzen_deployment_data = tdata.get("watzen", {}).get("deployment", {})
            logger.debug("configuration: watzen: old")

    @staticmethod
    def _default_endpoint_name(pattern: str, collection: Optional[str]) -> str:
        return f"{_DEFAULT_NAME}/{collection if collection else pattern}"

    def raw(self) -> Dict[str, Any]:
        return self.configuration_data

    # [stepzen.cli]
    # endpoint = "testing/dbs"
    def stepzen_cli(self, key: str, opt: Optional[str] = None) -> Optional[str]:
        return self.stepzen_cli_data.get(key, opt)

    # [wxflows.deployment]
    def _watzen_deployment(self, key: str, opt: Optional[str] = None) -> Optional[str]:
        """used to grab *strings* from the deployment section
        deprecate
        """
        return self.watzen_deployment_data.get(key, opt)

    def deployment_flows(self) -> str:
        result = self.watzen_deployment_data.get("flows", "")
        if isinstance(result, list):
            return "\n".join(result)
        return result

    def deployment_flow_files(self) -> List[str]:
        result = self.watzen_deployment_data.get("flow_files", [])
        ff = self.watzen_deployment_data.get("flow_file")
        if ff is not None:
            if isinstance(ff, str):
                result.append(ff)
            else:
                raise RuntimeError("flow_file is must be a single string")
        return result

    def deployment_configuration_file(self) -> Optional[str]:
        """this is the stepzen config.yaml"""
        return self.watzen_deployment_data.get("configuration_file")

    def deployment_preexisting_endpoint(self) -> Optional[str]:
        return self.watzen_deployment_data.get("preexisting", {}).get("endpoint")

    def deployment_public_queries(self) -> List[str]:
        return self.watzen_deployment_data.get("public_queries", [])

    # [wxflows.deployment.rag_v1]
    def watzen_deployment_pattern(
        self, pattern: str, key: str, opt: Optional[str] = None
    ) -> Optional[str]:
        """
        returns the *raw* pattern data
        """
        pat = self.watzen_deployment_data.get(pattern)
        if not pat:
            return opt
        return pat.get(key, opt)

    def deployment_embedding_model(self):
        return self.watzen_deployment_data.get("embedding_model", "")

    def endpoint_name(self) -> str:
        """
        returns the "endpoint" from either
        [wxflows.deployment]
        endpoint_name=x
        or
        [stepzen.cli]
        name=x
        or default
        """
        endpoint_name = self.watzen_deployment_data.get("endpoint_name")
        if isinstance(endpoint_name, str):
            return str(endpoint_name)  # unwind toml

        v = self.stepzen_cli("endpoint")
        if v:
            return v
        pattern = self.pattern()
        collection = self.pattern_collection()
        return self._default_endpoint_name(pattern, collection)

    def pattern(self) -> str:
        """
        pattern or kind of schema to deploy
        should be a deployment prefix but it's so important, we expose it directly for now.
        """

        # new model is no pattern declaration
        # NOTE: if pattern is renamed, update here.
        if "pattern" not in self.watzen_deployment_data:
            return _DEFAULT_PATTERN

        # Old model was there was a 'pattern=pattern' in the deployment section.

        # must be careful with the pattern's
        # because there is a conflict with the tags
        # pattern, flows, ai_engine, public_queries,
        # configuration_file, embedding_model, endpiont
        # are all reserved and cannot be used as a pattern
        # also: preexisting
        v = self._watzen_deployment("pattern")
        if v in [
            "pattern",
            "flows",
            "ai_engine",
            "public_queries",
            "configuration_file",
            "embedding_model",
            "endpoint",
        ]:
            raise CLIError(f"{v} is not a legal pattern name: reserved")
        return v if v else _DEFAULT_PATTERN

    def pattern_data(self) -> Dict[str, Any]:
        pattern = self.pattern()
        # new model is to have [wxflows.deployment.source.aicore]
        # vs wxflows.deployment.aicore or wxflows.deployment.rag_v1
        if (
            "source" in self.watzen_deployment_data
            and pattern in self.watzen_deployment_data["source"]
        ):
            v = self.watzen_deployment_data["source"].get(pattern)
        else:
            v = self.watzen_deployment_data.get(self.pattern())
        if not v:
            return {}
        return v

    _ai_engines_name_for_gql = {
        "BAM": "BAM",
        "WATSONX.AI": "WATSONX",
        "WATSONX": "WATSONX",
    }

    @classmethod
    def _ai_engine_name(cls, name: str) -> str:
        return cls._ai_engines_name_for_gql.get(name, name).upper()

    def raw_deployment_ai_engine(self) -> str:
        """convert to uppercase to match ENUM"""
        v = self._watzen_deployment("ai_engine")
        if v:
            return self._ai_engine_name(v)
        return ""

    def deployment_ai_engine(self) -> str:
        """convert to uppercase to match ENUM"""
        v = self.raw_deployment_ai_engine()
        return v if v else self._ai_engine_name(_DEFAULT_GENAI)

    def deployment_endpoints(self) -> Endpoints:
        """endpoints are deployment.endpoint values and the current version allows for
                imports or detailed configuration on the current endpoint

        [wxflows.deployment.endpoint.imports]
        name.url="https://jatopata.us-east-a.ibm.stepzen.net/watzen-genai/watsonaidocs/__graphql"
        name.prefix="myprefix"
        # set to environment variable name that contains the key
        #   in your environment or .env
        # name.apikey_envname="ADMINKEY"

        [wxflows.deployment.endpoint]
        configuration.name.key="value"
        configuration.myconfiguration.configname="STEPZEN_KEY"
        # deployment.identity.issuer=""
        # deployment.identity.subject=""
        # deployment.identity.audience=""
        # deployment.identity.claims=[]
        deployment.identity.jwksendpoint="JUNK"
        deployment.identity.oidcconfigurationendpoint="https://.../.well-known/openid-configuration"
        # oidcconfigurationendpoint
        # userinfoendpoint
        # introspectendpoint
        """
        # an older version was used for only imports but in a different form
        # and that code is deprecated
        return Endpoints(self.watzen_deployment_data.get("endpoint", {}))

    def pattern_collection(self) -> str:
        """
        collection or kind of schema to deploy
        """
        pattern_data = self.pattern_data()
        return pattern_data.get("collection", "")  # default?

    def pattern_embedding_model(self) -> str:
        pattern_data = self.pattern_data()
        return pattern_data.get("embedding_model") or self.deployment_embedding_model()

    def pattern_tsv_files(self) -> Optional[List[str]]:
        pattern_data = self.pattern_data()
        return pattern_data.get("tsv_files", [])  # default?

    def pattern_ai_engine(self) -> str:
        """retrieve ai engine from pattern else parent - convert to uppercase to match ENUM"""

        pattern_data = self.pattern_data()
        return self._ai_engine_name(pattern_data.get("ai_engine") or self.deployment_ai_engine())

    def pattern_search_engine(self) -> Optional[str]:
        """retrieve ai engine from pattern else parent - convert to upper case"""
        pattern_data = self.pattern_data()
        if pattern_data.get("search_engine"):
            return pattern_data.get("search_engine", "").upper()
        docstore = self.pattern_docstore()
        if not docstore:
            return None
        dstype = docstore.type()
        if dstype is None:
            return ""
        return dstype.upper()

    def pattern_data_directory(self) -> Optional[str]:
        pattern_data = self.pattern_data()
        return pattern_data.get("data_directory")

    def pattern_data_type(self) -> Optional[str]:
        pattern_data = self.pattern_data()
        return pattern_data.get("data_type")

    def pattern_chunk_size(self) -> Optional[str]:
        pattern_data = self.pattern_data()
        return pattern_data.get("chunk_size")

    def pattern_chunk_overlap(self) -> Optional[str]:
        pattern_data = self.pattern_data()
        return pattern_data.get("chunk_overlap")

    def pattern_docstore(self) -> Optional[DocStore]:
        pattern_data = self.pattern_data()
        v: Optional[Dict[str, Any]] = pattern_data.get("documentstore")
        if not v:
            # allow missing docstore in this case.
            if self.pattern() == _DEFAULT_PATTERN:
                return DocStore()
            return None
        if not isinstance(v, dict):
            return None
        return DocStore(v)

    def pattern_env(self, prefix: str = "", minimal: bool = False) -> Optional[Dict[str, str]]:
        """
        return a subset of the pattern data
        """
        pattern_data = self.pattern_data()
        # must have pattern data *and* collection
        data = {}
        if not pattern_data or "collection" not in pattern_data and not pattern_data["collection"]:
            v = self.raw_deployment_ai_engine()
            if v:
                data = {"AI_ENGINE": v}
            if not prefix:
                prefix = "STEPZEN_WXFLOWS_"
        else:  # have pattern data
            # for simplicity, always have a value
            data = {
                # ENUMs
                "AI_ENGINE": self.pattern_ai_engine(),
                "SEARCH_ENGINE": self.pattern_search_engine(),
                "COLLECTION": self.pattern_collection(),
                "EMBEDDING_MODEL": self.pattern_embedding_model(),
                "DOCUMENTSTORE_TYPE": "",
                "DOCUMENTSTORE_SUBTYPE": "",
            }
            docstore = self.pattern_docstore()
            if docstore:
                data["DOCUMENTSTORE_TYPE"] = docstore.type()
                if docstore.subtype():
                    data["DOCUMENTSTORE_SUBTYPE"] = docstore.subtype()
            pattern_name = self.pattern().upper()
            if not prefix:
                prefix = f"STEPZEN_WXFLOWS_{pattern_name}_"
        result = {prefix + k: data[k] for k in data}
        # de-tomlize it for YAML dumps
        cleanresult = json.loads(json.dumps(result))
        # the SDK only really wants these from the TOML?
        if minimal:
            return {
                prefix + k: cleanresult.get(prefix + k)
                for k in ["COLLECTION", "EMBEDDING_MODEL", "AI_ENGINE"]
                if prefix + k in cleanresult
            }
        return cleanresult


class TOMLConfiguration(Configuration):
    def __init__(self, location: str = ""):
        loc, tf, toml_prefix, tdata = _get_toml(location)
        self.toml_location_data = loc
        self.toml_name = tf
        # list of prefixes.
        self.toml_prefix_value = toml_prefix
        super(TOMLConfiguration, self).__init__(tdata)

    def toml_location(self) -> str:
        return self.toml_location_data

    def toml_path(self) -> str:
        return os.path.join(self.toml_location_data, self.toml_name)

    def toml_prefix(self) -> List[str]:
        return self.toml_prefix_value
