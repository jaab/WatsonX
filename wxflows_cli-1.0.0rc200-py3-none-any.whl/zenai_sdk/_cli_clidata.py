# Copyright IBM Corp. 2023, 2024
import argparse
import asyncio
import collections
import getpass
import logging
import os
import re
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import dotenv
import yaml
from inquirer.errors import ValidationError as InquirerValidationError

from .cli_error import (
    CLIStepzenConfiguration,
    CLIStepzenConfigurationLogin,
    CLIStepzenConfigurationLoginBad,
)
from .configuration import TOMLConfiguration
from .stepzen_services import IntrospectionServices, StepzenLogin, StepzenServices
from .zenai_api import AsyncZenUpload

logger = logging.getLogger("wxflows")


def _validate_account_name(_, current: Optional[str]) -> bool:
    accountRegex = "^[a-z][a-z\\d\\-]{0,62}$"
    if not current:
        raise InquirerValidationError("", reason="No environment name")
    if len(current) > 63:
        raise InquirerValidationError(
            "",
            reason="An environment name should only contain letters, digits, and dashes and < 63",
        )
    if not re.match(accountRegex, current):
        raise InquirerValidationError(
            "", reason="An environment name should only contain letters, digits, and dashes"
        )
    return True


def get_input(s: str) -> str:
    return input(s)


class CLIData:
    """CLI environment data"""

    GEN1DOMAIN = "stepzen.net"
    # stepzen-config elements
    ACCOUNT_DOMAIN = "account_domain"
    ACCOUNT = "account"
    ACCOUNT_REAL = "account"

    DOMAIN = "domain"
    ADMINKEY = "adminkey"
    APIKEY = "apikey"
    UUID = "uuid"

    IBM_CLOUD = "ibmcloud"
    SERVICE_INSTANCE = "serviceInstance"
    ZENCTL2 = "zenctl2"
    DEPLOYMENT_TYPE = "deploymentType"

    STEPZEN_CONFIG_CONTENT = "STEPZEN_CONFIG_CONTENT"

    def create_init(
        self,
        location: str,
        theconfig: Dict[str, Any],
        feature_flags: Optional[List[str]] = [],
        verbose: bool = False,
    ):
        self.location = location
        self.theconfig = theconfig
        self.verbose_flag = verbose
        self.features_flags = feature_flags

        self.account: str = self.theconfig[self.ACCOUNT]
        self.account_domain: str = self.theconfig[self.ACCOUNT_DOMAIN]
        extras = {}

        # this section
        #     "ibmcloud": {
        #         "apikey": "IBM-CLOUD-API-KEY-HERE",
        #          "defaultWatsonxProjectId": "0fea01b9-3ad8-4087-84e9-675817e72b65.."
        #      }
        # may also include defaultWatsonxSpaceId, defaultWatsonxHostname
        if self.IBM_CLOUD in self.theconfig:
            # simple mapping without checks
            ibmcloud_mapping = {
                "STEPZEN_IBMCLOUD_APIKEY": "apikey",
                "STEPZEN_WATSONX_AI_APIKEY": "apikey",
                "STEPZEN_WATSONX_PROJECTID": "defaultWatsonxProjectId",
                "STEPZEN_WATSONX_HOST": "defaultWatsonxHostname",
            }

            ibmcloud = self.theconfig[self.IBM_CLOUD]
            for k in ibmcloud_mapping:
                mk = ibmcloud_mapping.get(k)
                if mk and mk in ibmcloud:
                    extras[k] = ibmcloud[mk]
        self.domain: str = self.theconfig[self.DOMAIN]
        self.adminkey: str = self.theconfig[self.ADMINKEY]
        self.apikey: str = self.theconfig[self.APIKEY]
        self.service_instance: Optional[Dict[str, str]] = self.theconfig.get(self.SERVICE_INSTANCE)
        # these are auto-injected
        self._injected = {
            # deprecate
            "STEPZEN_WATZENUSER_ACCOUNT": self.account,
            "STEPZEN_WATZENUSER_ENVIRONMENT": self.account,
            "STEPZEN_WATZENUSER_DOMAIN": self.domain,
            "STEPZEN_WATZENUSER_ADMINKEY": self.adminkey,
            # latest
            "STEPZEN_WXFLOWSUSER_ENVIRONMENT": self.account,
            "STEPZEN_WXFLOWSUSER_DOMAIN": self.domain,
            "STEPZEN_WXFLOWSUSER_ADMINKEY": self.adminkey,
            "STEPZEN_WXFLOWSUSER_APIKEY": self.apikey,
        }

        self._injected.update(extras)
        logger.debug(f"injected environment keys {self._injected.keys()}")
        self.env_values = self._compute_env(location, self._injected)

    @staticmethod
    def configpath():
        return os.environ.get("STEPZEN_CONFIG_FILE") or os.path.expanduser(
            "~/.stepzen/stepzen-config.yaml"
        )

    @classmethod
    def validate_stepzen_configuration(cls, stepzen_config: Dict[str, Any]) -> Dict[str, Any]:
        if not stepzen_config or not isinstance(stepzen_config, dict):
            raise CLIStepzenConfigurationLoginBad
        # cross check that the file is structured properlyand contains all that we expect
        # [code assumes for now for the most part]
        serviceInstance = stepzen_config.get(cls.SERVICE_INSTANCE)
        domain = cls.GEN1DOMAIN
        if serviceInstance and cls.ZENCTL2 in serviceInstance:
            urlinfo = urlparse(serviceInstance["zenctl2"])
            # 'zenctl2': 'https://stepzen.us-east-a.ibm.stepzen.net/api/zenctl/__graphql
            if urlinfo.scheme in ["http", "https"]:  # http for on-premise, and local
                parts = urlinfo.netloc.split(".", 1)
                if len(parts) > 1 and parts[0] == "stepzen":
                    domain = parts[1]
                else:
                    domain = urlinfo.netloc
        if cls.ADMINKEY not in stepzen_config or cls.ACCOUNT not in stepzen_config:
            raise CLIStepzenConfigurationLoginBad
        account = stepzen_config[cls.ACCOUNT]
        logger.debug(
            f"Domain: {domain} environment {account} lengths {len(stepzen_config.get(cls.ADMINKEY, ''))}"
            f" {len(stepzen_config.get(cls.APIKEY, ''))}"
        )

        stepzen_config[cls.ACCOUNT_DOMAIN] = f"{account}.{domain}"  # inferred
        stepzen_config[cls.DOMAIN] = domain  # inferred
        return stepzen_config

    @classmethod
    def create(
        cls,
        location: str,
        feature_flags: Optional[List[str]] = [],
        credentials_force_update: str = "",
        endpoint: str = "api.zenai.stepzen.net",
        verbose: bool = False,
    ):
        """
        gets current stepzen config
        """

        if credentials_force_update:
            logger.debug(f"Checking credentials {len(credentials_force_update)}")
            stepzen_config = yaml.safe_load(credentials_force_update)
            cls.validate_stepzen_configuration(stepzen_config)
            with open(cls.configpath(), "w") as f:
                f.write(credentials_force_update)
            logger.debug(f"Writing credentials {len(credentials_force_update)}")

        # todo: beef up this code or figure out a better way to handle this.
        # the format/structure of the config is owned by the stepzen cli not
        # wxflows.
        # Thought: should we have a "stepzen" service that takes in a "configuration"
        # as a string (vs. an object) and returns information if valid?
        # Thus, the ownership of the config file would then belong to the server.  [LATER]
        # Todo: another pass over this code
        if cls.STEPZEN_CONFIG_CONTENT in os.environ:
            config_content = os.environ.get(cls.STEPZEN_CONFIG_CONTENT)
            # same as stepzen cli
            stepzen_config = {}
            if config_content is not None:
                stepzen_config = yaml.safe_load(config_content)
        else:
            thepath = cls.configpath()
            if not os.path.exists(thepath):
                print("No existing credentials found, login is required", file=sys.stderr)
                raise CLIStepzenConfigurationLogin

            with open(thepath, "r", encoding="utf8") as f:
                stepzen_config = yaml.safe_load(f)
        stepzen_config = cls.validate_stepzen_configuration(stepzen_config)

        self = cls()
        self.create_init(
            location,
            stepzen_config,
            (feature_flags or []),
            verbose=verbose,
        )
        return self

    def is_verbose(self) -> bool:
        return self.verbose_flag

    def set_verbose(self):
        self.verbose_flag = True

    def _compute_env(self, location: str, autovalues: Dict[str, str]) -> Dict[str, Optional[str]]:
        env_values = {}  # do this for pyright
        env_values.update(autovalues)
        # print("autovalues", env_values)
        # copy out STEPZEN_ vars from environ; add WATSONX_ as well.
        env_values.update(
            {
                (k, os.environ[k])
                for k in os.environ
                if k.startswith("STEPZEN_") or k.startswith("WATSONX_")
            }
        )
        if not location:
            logger.debug("defaulting to .env")
            location = ".env"
        if location:
            if Path(location).exists():
                if Path(location).is_file():  # location points to the file...
                    logger.debug(f"environment location is a file: {location}")
                    pth = location
                elif Path(location).is_dir():
                    pth = os.path.join(location, ".env")
                    logger.debug(f"environment location is directory, looking for: {pth}")
                else:
                    logger.debug(f"environment location is not a directory or file: {location}")
                    pth = location
            else:
                logger.debug(f"environment location does not exist: {location}")
                pth = location
            values = dotenv.dotenv_values(pth) or {}
            env_values.update(values)
        return env_values

    def is_feature(self, feature: str) -> bool:
        """
        feature enabled if in feature flags, enumerate them here.
        - loader.graphql.debug - turns on debug
        - loader.graphql.debug.base - turns on the base endpoint
        """
        if self.features_flags is None:
            return False
        return feature in self.features_flags

    def injected(self) -> List[str]:
        """list of injected values - useful so we never ask for them"""
        return [x for x in self._injected.keys()]

    def env(self) -> Dict[str, Optional[str]]:
        """
        env from .env and injected values
        currently we exclude non prefixed os.environ values out of an abudance of caution
        """
        return self.env_values

    def is_zenctl2(self) -> bool:
        return self.theconfig[self.DOMAIN] != "stepzen.net"

    def is_localhost(self) -> bool:
        parts = self.theconfig[self.DOMAIN].split(":")
        if len(parts) < 0:
            return False
        # better way?
        return parts[0] == "127.0.0.1"

    @classmethod
    def _login(
        cls,
        account: str,
        domain: str,
        password: str,
        introspection: Optional[str],
        skip_tls_verify=False,
    ) -> Tuple[str, str, str, str]:
        """
        will take an account, domain and admin key
        check it with stepzen
        write it if valid
        """
        logger.debug(f"_login with {account} {domain} {introspection} len apikey {len(password)}")
        login = StepzenLogin(
            account, domain, password, introspection, skip_tls_verify=skip_tls_verify
        )
        stepzen = StepzenServices(login)

        if introspection:
            introspection_services = IntrospectionServices(login)
            logger.debug(f"checking introspection for {introspection}")
            asyncio.run(introspection_services.validate())

        apikeys = asyncio.run(stepzen.validate())

        apikey = apikeys[0] if len(apikeys) > 0 else ""
        login = CLIData
        template = collections.OrderedDict(
            {
                "account": account,
                "adminkey": password,
                "apikey": apikey,
                "uuid": str(uuid.uuid4()),
                "serviceInstance": {
                    "deploymentType": "local",
                    "zenctl2": f"https://stepzen.{domain}/api/zenctl/__graphql",
                },
            }
        )
        if introspection:
            if not isinstance(template["serviceInstance"], dict):
                raise RuntimeError("internal error: template has unexpected form in login")
            template["serviceInstance"]["introspection"] = introspection
            template["serviceInstance"]["dbintrospection"] = introspection

        def ordered_dict_yaml(dumper, data):
            return dumper.represent_dict(data.items())

        yaml.add_representer(collections.OrderedDict, ordered_dict_yaml, Dumper=yaml.SafeDumper)
        thepath = cls.configpath()

        if not os.path.exists(os.path.dirname(thepath)):
            os.mkdir(os.path.dirname(thepath))
        with open(thepath, "w") as f:
            yaml.safe_dump(template, f)
        return account, domain, password, apikey

    @classmethod
    def overwrite_check(cls):
        if not os.path.exists(cls.configpath()):
            return

        okay = input(
            "You have an existing stepzen configuration which seems to be invalid?  Overwrite it? (y/N): "
        )
        replace = False
        if okay.strip().lower() == "y":
            replace = True

        if not replace:
            raise CLIStepzenConfiguration("okay, will not overwrite existing login.")

    @classmethod
    def login(
        cls,
        account: Optional[str],
        domain: Optional[str],
        password: Optional[str],
        introspection_arg: Optional[str] = None,
        skip_tls_verify=False,
    ) -> Tuple[str, str, str, str]:
        # this is not as friendly as it should be, but go with this for now as login is a rare event.
        if not account:
            account = input("Provide your watsonx Flows Engine environment name: ")
            if not account or not _validate_account_name("", account):
                print("accountname is not valid", file=sys.stderr)
                sys.exit(1)
        if not domain:
            # base option is good for now though not particularly friendly
            # future: possibly use the usual trick of giving them a choice from a list
            # but careful because we need to support custom domains...

            # issue: how do they know these, what help do we provide?
            default_domain = "us-east-a.ibm.stepzen.net"
            domain = input(
                f"Provide the the domain of your environment (default: {default_domain}): "
            )
            if not domain:
                domain = default_domain
                print(f"Defaulting to {domain}")

        if not password:
            password = getpass.getpass("Provide the admin key for your environment: ")

        try:
            account = account.strip()
            _validate_account_name("", account)
            domain = domain.strip()
            password = password.strip()
            logger.debug(f"login: {account} {domain} passwd len {len(password)}")
        except RuntimeError as e:
            print(
                f"Unable to get your environment, domain, or password or your enviroment was invalid: {e}"
            )
        else:
            # account, domain  and password already set.
            _validate_account_name("", account)

        try:
            if not isinstance(account, str):
                raise RuntimeError(f"invalid environment {account}")
            if not isinstance(domain, str):
                raise RuntimeError(f"invalid domain {domain}")
            if not isinstance(password, str):
                raise RuntimeError("invalid password")
            result = cls._login(account, domain, password, introspection_arg, skip_tls_verify)
        except RuntimeError as e:
            raise RuntimeError(
                f"Unable to validate your login using environment '{account}' domain '{domain}': {e}"
            )
        return result


#### model
def _get_vup(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    account: str,
    kind: str,
    debug: bool = False,
) -> AsyncZenUpload:
    endpoint_name = toml_data.endpoint_name()
    embedding_model = toml_data.pattern_embedding_model()

    ai_engine = toml_data.pattern_ai_engine()
    login = StepzenLogin(
        cli.account,
        cli.domain,
        cli.adminkey,
        service_instances=cli.service_instance,
        skip_tls_verify=cli.is_feature("skip-tls-verify"),
    )
    services_endpoint = login.endpoint_uri(endpoint_name)

    apikey = cli.apikey
    adminkey = cli.adminkey
    zup = AsyncZenUpload(
        account,
        apikey,
        adminkey,
        services_endpoint,
        ai_engine=ai_engine,
        default_model=embedding_model,
    )
    return zup


class ExtensionsArguments:
    """simple abstraction around extensions arguments"""

    def __init__(self, args: Optional[argparse.Namespace]):
        if not args:
            self.user_extension_directories: Optional[List[str]] = None
            self.pattern_source_directories: Optional[List[str]] = []
            return

        self.user_extension_directories: Optional[List[str]] = args.user_extension_directories
        self.pattern_source_directories: Optional[List[str]] = []
        # for now a single value
        if args.source_directory:
            self.pattern_source_directories = [args.source_directory]
