# Copyright IBM Corp. 2023, 2024

"""
version command implementation
"""
import sys

from .__about__ import __version__
from .stepzen_services import StepzenCli


def cmd_version():
    print("wxflows")
    print(f"version: {__version__}")
    print(f"Python: {sys.version}")
    print(f"Python path: {sys.executable}")
    print("")
    print("StepZen CLI")
    response = StepzenCli.exec(["version"])
    print(f"path: {StepzenCli.stepzen_bin}")
    print(f'version: {response.stdout.decode("utf-8").strip() if response.stdout else ""}')
